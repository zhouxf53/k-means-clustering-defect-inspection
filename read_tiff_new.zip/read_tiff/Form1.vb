﻿Imports System.ComponentModel
Imports System.IO

Public Class Form1

    Function GetAllFiles(MyPath As String) As List(Of String)
        Dim result As New List(Of String)()
        Dim dirs As String() = Directory.GetDirectories(MyPath)
        Dim files As String() = Directory.GetFiles(MyPath, "*.tif")
        If (files.Length > 0) Then
            result.AddRange(files)
        End If
        For Each MyDir As String In dirs
            result.AddRange(GetAllFiles(MyDir))
        Next
        Return result
    End Function


    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            'FolderBrowserDialog1.RootFolder = Environment.SpecialFolder.MyComputer
            FolderBrowserDialog1.SelectedPath = My.Settings.LastPath
        Catch ex As Exception
        End Try

        If FolderBrowserDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Dim path As String = FolderBrowserDialog1.SelectedPath
            My.Settings.LastPath = path
            My.Settings.Save()
            BackgroundWorker1.RunWorkerAsync(path)
        End If
    End Sub

    Function MainProg(
        ByVal path As String,
        ByVal worker As BackgroundWorker,
        ByVal e As DoWorkEventArgs)

        Dim MyFiles As List(Of String) = GetAllFiles(path)

        Dim ParentOld As String
        Dim count As Integer = 1
        Dim TotalCount As Integer = MyFiles.Count
        Dim ProgressCount As Integer = 1

        For Each MyFile As String In MyFiles

            Dim myCOMPIX As New WinTES2FileIO.WinTES2TIFF

            'Dim mycompixErr As New WinTES2FileIO.WinTES2Error
            'mycompixErr = myCOMPIX.OpenTIFF(MyFile)
            myCOMPIX.OpenTIFF(MyFile)
            Dim Temp(,) As Single
            Dim vpmax, hpmax As Integer
                Temp = myCOMPIX.WinTES2Image
                hpmax = Temp.GetLength(0)
            vpmax = Temp.GetLength(1)

            'releaseExcelObject(myCOMPIX)

            Dim MyParent1 As String = System.IO.Path.GetDirectoryName(MyFile)
            Dim ParentFolderOnly As String = MyParent1.Split("\").Last()
            Dim MyParent2 As String = System.IO.Path.GetDirectoryName(MyParent1)
            If ParentOld <> MyParent1 Then
                count = 1
            End If
            Dim FILE_NAME As String = MyParent1 + "\" + ParentFolderOnly + "_" + count.ToString("D3") + ".txt"

            Dim objWriter As New System.IO.StreamWriter(FILE_NAME)

            For j As Integer = 1 To hpmax
                Dim outp(vpmax - 1) As String

                Dim aline As String = ""
                For k As Integer = 1 To vpmax
                    outp(k - 1) = Temp(j, k).ToString()
                Next
                aline = String.Join(vbTab, outp)
                objWriter.WriteLine(aline)
            Next
            objWriter.Close()

            Dim percentComplete As Integer = CSng(ProgressCount) / CSng(TotalCount) * 100
            worker.ReportProgress(percentComplete)

            count = count + 1
            ParentOld = MyParent1
            ProgressCount = ProgressCount + 1

            ' Catch exc As Exception
            ' MessageBox.Show("Error opening: " & MyFile)
            ' End Try
        Next

    End Function

    Private Sub releaseExcelObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub

    Private Sub BackgroundWorker1_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorker1.DoWork
        Dim worker As BackgroundWorker = CType(sender, BackgroundWorker)
        e.Result = MainProg(e.Argument, worker, e)
    End Sub

    Private Sub BackgroundWorker1_ProgressChanged(sender As Object, e As ProgressChangedEventArgs) Handles BackgroundWorker1.ProgressChanged
        ProgressBar1.Value = e.ProgressPercentage
    End Sub

    Private Sub BackgroundWorker1_RunWorkerCompleted(sender As Object, e As RunWorkerCompletedEventArgs) Handles BackgroundWorker1.RunWorkerCompleted
        MessageBox.Show("Finished!")
        'Me.Close()
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Location = New Point(My.Settings.X, My.Settings.Y)
    End Sub

    Private Sub Form1_FormClosing_1(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        My.Settings.X = Me.Location.X
        My.Settings.Y = Me.Location.Y
        My.Settings.Save()
    End Sub
End Class
